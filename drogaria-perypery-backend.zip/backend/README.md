# Backend Drogaria PeryPery — Guia Completo

Este é o backend **real** da Drogaria PeryPery: banco de dados de verdade,
login seguro, painel administrativo, controle de estoque, pedidos e
pagamento via Mercado Pago (Pix e cartão).

## ⚠️ Antes de tudo: o que isto NÃO faz sozinho

Eu (Claude) escrevi todo o código, mas não consigo:
1. **Hospedar isto ao vivo** — você precisa publicar em um serviço de
   hospedagem (indico o Render.com abaixo, tem plano gratuito).
2. **Criar sua conta de recebimento no Mercado Pago** — isso exige CNPJ/CPF
   e verificação de identidade, que só o dono da farmácia pode fazer.
3. **Garantir conformidade jurídica com a LGPD** — escrevi um rascunho de
   política de privacidade (`seo-frontend/politica-de-privacidade.md`), mas
   ela precisa ser revisada por um advogado antes de publicar.

Feito o aviso, aqui está o passo a passo real para colocar tudo no ar. 👇

---

## 1. Rodando no seu computador (teste local)

```bash
cd backend
npm install
cp .env.example .env
```

Abra o arquivo `.env` e preencha pelo menos:
- `JWT_SECRET` (qualquer texto aleatório grande)
- `ADMIN_EMAIL` e `ADMIN_SENHA` (login do primeiro administrador)

Depois:
```bash
npm run seed     # cria o banco de dados com o admin e os produtos iniciais
npm start        # inicia o servidor
```

Acesse:
- API: `http://localhost:3000/api/status`
- Painel administrativo: `http://localhost:3000/admin`
  (entre com o `ADMIN_EMAIL`/`ADMIN_SENHA` que você colocou no `.env`)

## 2. Publicando de verdade (Render.com — tem plano gratuito)

1. Crie uma conta em [render.com](https://render.com) e conecte seu GitHub.
2. Suba a pasta `backend/` para um repositório no GitHub.
3. No Render, clique em **New > Web Service**, escolha o repositório.
4. Configure:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. Em **Environment Variables**, adicione as mesmas variáveis do seu `.env`
   (nunca suba o `.env` para o GitHub — o `.gitignore` já está configurado
   para isso).
6. Depois do primeiro deploy, rode o seed uma vez (Render tem um "Shell"
   dentro do painel do serviço): `npm run seed`.
7. O Render te dá um domínio grátis tipo `perypery-backend.onrender.com`,
   já com HTTPS automático.

## 3. Ligando o site (frontend) a este backend

O site que você já tem (o arquivo `index.html`) hoje funciona sozinho,
sem backend — o carrinho e o "criar conta" ficam salvos só no navegador
de cada pessoa. Para ele conversar com este backend de verdade, alguém
com conhecimento em programação (ou eu, em uma próxima conversa) precisa
trocar as funções de carrinho/login do site para chamar esta API
(`fetch('https://SEU-BACKEND.onrender.com/api/...')`) em vez de usar o
`localStorage`. Não fiz essa troca agora para não quebrar o site que já
está funcionando — me avise se quiser que eu faça essa integração.

## 4. Configurando o Mercado Pago (Pix e cartão)

1. Crie uma conta em
   [mercadopago.com.br/developers/panel](https://www.mercadopago.com.br/developers/panel).
2. Pegue o **Access Token de produção** (não o de teste).
3. Cole em `MERCADOPAGO_ACCESS_TOKEN` nas variáveis de ambiente do Render.
4. No painel do Mercado Pago, em **Webhooks**, cadastre a URL:
   `https://SEU-BACKEND.onrender.com/api/pagamentos/webhook`
   (isso é o que confirma automaticamente quando um pagamento é aprovado).

## 5. Domínio próprio e SSL

- Compre um domínio (ex: registro.br, ~R$40/ano para `.com.br`).
- No Render, em **Settings > Custom Domain**, aponte seu domínio — o
  certificado SSL (o cadeado de segurança) é gerado automaticamente,
  de graça.

## 6. SEO

Os arquivos em `seo-frontend/` (`robots.txt`, `sitemap.xml` e as meta tags)
devem ficar junto do seu `index.html`, na raiz do site. Depois, cadastre o
site no [Google Search Console](https://search.google.com/search-console)
e envie o `sitemap.xml` por lá.

## 7. Estrutura de pastas deste backend

```
backend/
├── server.js              # arquivo principal, junta tudo
├── package.json
├── .env.example            # copie para .env e preencha
├── db/
│   ├── schema.sql          # estrutura das tabelas
│   ├── database.js         # conexão com o banco
│   └── seed.js              # cria admin + produtos iniciais
├── middleware/
│   └── auth.js              # verifica login/token
├── routes/
│   ├── auth.js               # cadastro/login
│   ├── products.js           # produtos + estoque
│   ├── orders.js              # pedidos (baixa estoque de verdade)
│   ├── payments.js            # Mercado Pago (Pix/cartão)
│   ├── lgpd.js                 # exportar/excluir dados (LGPD)
│   └── admin.js                # dashboard e clientes
├── admin/
│   ├── index.html              # painel administrativo
│   └── app.js
└── seo-frontend/
    ├── robots.txt
    ├── sitemap.xml
    ├── meta-tags-para-o-head.html
    └── politica-de-privacidade.md
```

## 8. Checklist de segurança já incluído no código

- [x] Senhas com hash bcrypt (12 rounds)
- [x] Login com JWT (expira em 7 dias)
- [x] Limite de tentativas de login (10 a cada 15 min)
- [x] Limite geral de requisições por IP
- [x] Cabeçalhos de segurança (Helmet)
- [x] CORS restrito ao domínio do seu site
- [x] Estoque baixado em transação (nunca vende o mesmo item duas vezes)
- [x] Rotas de admin protegidas por papel (`papel = 'admin'`)
- [x] Exportação e exclusão de dados (LGPD)

## 9. O que ainda depende de você (ou de contratar alguém)

- [ ] Criar a conta de hospedagem e publicar
- [ ] Criar a conta real no Mercado Pago (CNPJ)
- [ ] Revisar a política de privacidade com um advogado
- [ ] Indicar um Encarregado de Dados (DPO)
- [ ] Comprar o domínio
- [ ] Ligar o frontend a esta API (posso ajudar nisso quando quiser)
