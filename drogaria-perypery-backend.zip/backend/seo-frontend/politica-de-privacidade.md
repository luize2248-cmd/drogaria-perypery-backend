# Política de Privacidade — Drogaria PeryPery

⚠️ **AVISO IMPORTANTE:** este é um **rascunho técnico de partida**, escrito para
refletir o que o sistema realmente faz. Ele **não substitui a revisão de um
advogado** antes de publicar — a LGPD exige uma análise jurídica do seu caso
específico (por exemplo, se vocês also processam dados sensíveis de saúde ao
registrar receitas médicas, o que exige cuidados extras).

---

## 1. Quem somos
A Drogaria PeryPery, localizada na Av. Aderson Alves Ferreira, 1084, é a
controladora dos dados pessoais tratados neste site.

## 2. Quais dados coletamos
- **Cadastro:** nome, e-mail, telefone e senha (armazenada de forma
  criptografada, nunca em texto puro).
- **Pedidos:** endereço de entrega, forma de pagamento e itens comprados.
- **Receitas médicas enviadas:** quando você envia uma receita pelo site,
  ela é encaminhada diretamente ao WhatsApp da farmácia — não fica
  armazenada no banco de dados do site.
- **Navegação:** cookies de preferência (aceitos ou recusados por você) e,
  se você autorizar, permissão de notificações do navegador.

## 3. Para que usamos esses dados
- Processar e entregar seus pedidos.
- Entrar em contato sobre o andamento de uma compra.
- Cumprir obrigações fiscais (histórico de vendas).
- Melhorar o funcionamento do site.

Nunca vendemos seus dados a terceiros.

## 4. Com quem compartilhamos
- **Mercado Pago:** processa os pagamentos por Pix e cartão. Eles recebem
  apenas os dados necessários para a cobrança (nome, e-mail, valor).
- **WhatsApp:** ao enviar uma receita, currículo ou finalizar uma compra
  pelo WhatsApp, os dados trafegam pelos servidores do WhatsApp/Meta,
  fora do nosso controle direto.

## 5. Seus direitos (Art. 18 da LGPD)
Você pode, a qualquer momento:
- Baixar uma cópia de todos os seus dados (rota `/api/lgpd/meus-dados`
  no sistema, ou solicitando pelo suporte).
- Pedir a exclusão da sua conta (rota `/api/lgpd/minha-conta`).
- Corrigir dados incorretos entrando em contato pelo WhatsApp da farmácia.

## 6. Segurança
- Senhas são armazenadas com hash bcrypt (nunca em texto puro).
- Conexões usam HTTPS (fornecido automaticamente pela hospedagem).
- Autenticação por token (JWT) com expiração de 7 dias.

## 7. Encarregado de Dados (DPO)
**[PENDENTE]** — a LGPD exige que uma pessoa (ou empresa) seja formalmente
indicada como encarregada pelo tratamento de dados. Preencha aqui o nome e
o contato dessa pessoa antes de publicar o site.

## 8. Alterações desta política
Esta política pode ser atualizada. A data da última alteração ficará
sempre registrada no rodapé do site.

*Última atualização: [preencher ao publicar]*
