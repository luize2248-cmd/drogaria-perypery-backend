// Painel administrativo real: consome a própria API do backend (mesma origem).
const API = ''; // vazio = mesma origem do painel (ex: https://seusite.com/api/...)

function token() { return localStorage.getItem('perypery_admin_token'); }
function salvarToken(t) { localStorage.setItem('perypery_admin_token', t); }
function limparToken() { localStorage.removeItem('perypery_admin_token'); }

async function chamarAPI(caminho, opcoes = {}) {
  const resp = await fetch(API + caminho, {
    ...opcoes,
    headers: {
      'Content-Type': 'application/json',
      ...(token() ? { Authorization: 'Bearer ' + token() } : {}),
      ...(opcoes.headers || {}),
    },
  });
  const dados = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(dados.erro || 'Erro inesperado.');
  return dados;
}

function formatarMoeda(v) {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// ---------- LOGIN ----------
document.getElementById('formLogin').addEventListener('submit', async (e) => {
  e.preventDefault();
  const erroBox = document.getElementById('erroLogin');
  erroBox.classList.remove('show');
  try {
    const email = document.getElementById('loginEmail').value;
    const senha = document.getElementById('loginSenha').value;
    const resultado = await chamarAPI('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, senha }),
    });
    if (resultado.usuario.papel !== 'admin') {
      throw new Error('Esta conta não tem permissão de administrador.');
    }
    salvarToken(resultado.token);
    mostrarPainel();
  } catch (erro) {
    erroBox.textContent = erro.message;
    erroBox.classList.add('show');
  }
});

function sair() {
  limparToken();
  document.getElementById('painel').classList.remove('show');
  document.getElementById('telaLogin').style.display = 'flex';
}

async function mostrarPainel() {
  try {
    await chamarAPI('/api/auth/me'); // valida se o token ainda é válido
    document.getElementById('telaLogin').style.display = 'none';
    document.getElementById('painel').classList.add('show');
    carregarDashboard();
  } catch (erro) {
    sair();
  }
}

// ---------- NAVEGAÇÃO ----------
function mudarAba(aba) {
  ['dashboard', 'produtos', 'pedidos', 'clientes'].forEach(a => {
    document.getElementById('aba' + a[0].toUpperCase() + a.slice(1)).style.display = a === aba ? 'block' : 'none';
  });
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('active', b.dataset.aba === aba));
  if (aba === 'dashboard') carregarDashboard();
  if (aba === 'produtos') carregarProdutos();
  if (aba === 'pedidos') carregarPedidos();
  if (aba === 'clientes') carregarClientes();
}

// ---------- DASHBOARD ----------
async function carregarDashboard() {
  const d = await chamarAPI('/api/admin/dashboard');
  document.getElementById('cardsDashboard').innerHTML = `
    <div class="card"><div class="valor">${d.total_produtos}</div><div class="label">Produtos ativos</div></div>
    <div class="card"><div class="valor ${d.produtos_sem_estoque > 0 ? 'aviso-estoque' : ''}">${d.produtos_sem_estoque}</div><div class="label">Sem estoque</div></div>
    <div class="card"><div class="valor">${d.total_clientes}</div><div class="label">Clientes cadastrados</div></div>
    <div class="card"><div class="valor">${d.pedidos_hoje}</div><div class="label">Pedidos hoje</div></div>
    <div class="card"><div class="valor">${formatarMoeda(d.faturamento_hoje)}</div><div class="label">Faturado hoje (pago)</div></div>
    <div class="card"><div class="valor">${d.pedidos_pendentes}</div><div class="label">Pedidos em aberto</div></div>
  `;
}

// ---------- PRODUTOS ----------
async function carregarProdutos() {
  const produtos = await chamarAPI('/api/produtos/admin/todos');
  document.getElementById('tabelaProdutos').innerHTML = produtos.map(p => `
    <tr>
      <td>${p.nome}<br><small style="color:#8493a5;">${p.descricao || ''}</small></td>
      <td>${formatarMoeda(p.preco)}</td>
      <td>
        <input class="mini" type="number" value="${p.estoque}" onchange="atualizarEstoque(${p.id}, this.value)">
      </td>
      <td>${p.exige_receita ? 'Sim' : 'Não'}</td>
      <td><button class="btn-sm" onclick="excluirProduto(${p.id})">Excluir</button></td>
    </tr>
  `).join('');
}

async function criarProduto() {
  const nome = document.getElementById('pNome').value;
  const descricao = document.getElementById('pDescricao').value;
  const preco = parseFloat(document.getElementById('pPreco').value);
  const estoque = parseInt(document.getElementById('pEstoque').value, 10);
  const exige_receita = document.getElementById('pReceita').value === '1';

  if (!nome || isNaN(preco) || isNaN(estoque)) {
    alert('Preencha nome, preço e estoque corretamente.');
    return;
  }

  await chamarAPI('/api/produtos', {
    method: 'POST',
    body: JSON.stringify({ nome, descricao, preco, estoque, exige_receita }),
  });

  document.getElementById('pNome').value = '';
  document.getElementById('pDescricao').value = '';
  document.getElementById('pPreco').value = '';
  document.getElementById('pEstoque').value = '';
  carregarProdutos();
}

async function atualizarEstoque(id, novoValor) {
  await chamarAPI(`/api/produtos/${id}/estoque`, {
    method: 'PATCH',
    body: JSON.stringify({ estoque: parseInt(novoValor, 10) }),
  });
  carregarDashboard();
}

async function excluirProduto(id) {
  if (!confirm('Remover este produto da loja?')) return;
  await chamarAPI(`/api/produtos/${id}`, { method: 'DELETE' });
  carregarProdutos();
}

// ---------- PEDIDOS ----------
const STATUS_PEDIDO = ['recebido', 'preparando', 'saiu_para_entrega', 'pronto_retirada', 'concluido', 'cancelado'];
const STATUS_PAGAMENTO = ['pendente', 'pago', 'recusado', 'cancelado'];

async function carregarPedidos() {
  const pedidos = await chamarAPI('/api/pedidos/admin/todos');
  document.getElementById('tabelaPedidos').innerHTML = pedidos.map(p => `
    <tr>
      <td>#${p.id}</td>
      <td>${new Date(p.criado_em).toLocaleString('pt-BR')}</td>
      <td>${formatarMoeda(p.total)}</td>
      <td>${p.forma_pagamento}</td>
      <td>
        <select class="status-select" onchange="atualizarStatusPedido(${p.id}, 'status_pagamento', this.value)">
          ${STATUS_PAGAMENTO.map(s => `<option value="${s}" ${s === p.status_pagamento ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </td>
      <td>
        <select class="status-select" onchange="atualizarStatusPedido(${p.id}, 'status_pedido', this.value)">
          ${STATUS_PEDIDO.map(s => `<option value="${s}" ${s === p.status_pedido ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </td>
    </tr>
  `).join('');
}

async function atualizarStatusPedido(id, campo, valor) {
  await chamarAPI(`/api/pedidos/${id}/status`, {
    method: 'PATCH',
    body: JSON.stringify({ [campo]: valor }),
  });
}

// ---------- CLIENTES ----------
async function carregarClientes() {
  const clientes = await chamarAPI('/api/admin/clientes');
  document.getElementById('tabelaClientes').innerHTML = clientes.map(c => `
    <tr>
      <td>${c.nome}</td>
      <td>${c.email}</td>
      <td>${c.telefone || '—'}</td>
      <td>${new Date(c.criado_em).toLocaleDateString('pt-BR')}</td>
    </tr>
  `).join('');
}

// Se já existir um token salvo, tenta entrar direto sem pedir login de novo
if (token()) mostrarPainel();
