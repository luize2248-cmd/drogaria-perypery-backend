const jwt = require('jsonwebtoken');

// Exige que a pessoa esteja logada (qualquer papel)
function exigirLogin(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ erro: 'Token de acesso não enviado. Faça login novamente.' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.usuario = payload; // { id, papel, nome, email }
    next();
  } catch (e) {
    return res.status(401).json({ erro: 'Sessão inválida ou expirada. Faça login novamente.' });
  }
}

// Exige que, além de logada, a pessoa seja administradora
function exigirAdmin(req, res, next) {
  exigirLogin(req, res, () => {
    if (req.usuario.papel !== 'admin') {
      return res.status(403).json({ erro: 'Apenas administradores podem acessar isto.' });
    }
    next();
  });
}

module.exports = { exigirLogin, exigirAdmin };
