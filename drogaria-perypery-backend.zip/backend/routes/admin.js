const express = require('express');
const db = require('../db/database');
const { exigirAdmin } = require('../middleware/auth');

const router = express.Router();

// GET /api/admin/dashboard -> números reais para a tela inicial do painel
router.get('/dashboard', exigirAdmin, (req, res) => {
  const totalProdutos = db.prepare('SELECT COUNT(*) AS n FROM produtos WHERE ativo = 1').get().n;
  const produtosSemEstoque = db.prepare('SELECT COUNT(*) AS n FROM produtos WHERE ativo = 1 AND estoque = 0').get().n;
  const totalClientes = db.prepare("SELECT COUNT(*) AS n FROM usuarios WHERE papel = 'cliente'").get().n;
  const pedidosHoje = db.prepare("SELECT COUNT(*) AS n FROM pedidos WHERE date(criado_em) = date('now')").get().n;
  const faturamentoHoje = db.prepare(`
    SELECT COALESCE(SUM(total_centavos), 0) AS total FROM pedidos
    WHERE date(criado_em) = date('now') AND status_pagamento = 'pago'
  `).get().total;
  const pedidosPendentes = db.prepare(`
    SELECT COUNT(*) AS n FROM pedidos WHERE status_pedido NOT IN ('concluido', 'cancelado')
  `).get().n;

  res.json({
    total_produtos: totalProdutos,
    produtos_sem_estoque: produtosSemEstoque,
    total_clientes: totalClientes,
    pedidos_hoje: pedidosHoje,
    faturamento_hoje: faturamentoHoje / 100,
    pedidos_pendentes: pedidosPendentes,
  });
});

// GET /api/admin/clientes -> lista de clientes cadastrados
router.get('/clientes', exigirAdmin, (req, res) => {
  const clientes = db.prepare(`
    SELECT id, nome, email, telefone, criado_em FROM usuarios WHERE papel = 'cliente' ORDER BY criado_em DESC
  `).all();
  res.json(clientes);
});

// PATCH /api/admin/clientes/:id/promover -> transforma um cliente em administrador
router.patch('/clientes/:id/promover', exigirAdmin, (req, res) => {
  const usuario = db.prepare('SELECT * FROM usuarios WHERE id = ?').get(req.params.id);
  if (!usuario) return res.status(404).json({ erro: 'Usuário não encontrado.' });
  db.prepare("UPDATE usuarios SET papel = 'admin' WHERE id = ?").run(usuario.id);
  res.json({ ok: true });
});

module.exports = router;
