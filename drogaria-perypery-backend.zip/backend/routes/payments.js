// Integração real com o Mercado Pago. Para isto funcionar de verdade você precisa:
// 1. Criar uma conta em https://www.mercadopago.com.br/developers/panel
// 2. Pegar o "Access Token" de PRODUÇÃO (o de teste só simula, não recebe dinheiro real)
// 3. Colar esse token na variável MERCADOPAGO_ACCESS_TOKEN do seu .env
const express = require('express');
const { MercadoPagoConfig, Payment } = require('mercadopago');
const db = require('../db/database');
const { exigirLogin } = require('../middleware/auth');

const router = express.Router();

const client = new MercadoPagoConfig({
  accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN || 'CHAVE_NAO_CONFIGURADA',
});
const paymentClient = new Payment(client);

// POST /api/pagamentos/pix -> gera uma cobrança PIX real (QR code + copia-e-cola)
router.post('/pix', exigirLogin, async (req, res) => {
  const { pedido_id } = req.body;
  const pedido = db.prepare('SELECT * FROM pedidos WHERE id = ?').get(pedido_id);

  if (!pedido) return res.status(404).json({ erro: 'Pedido não encontrado.' });
  if (pedido.usuario_id !== req.usuario.id) return res.status(403).json({ erro: 'Este pedido não é seu.' });

  if (!process.env.MERCADOPAGO_ACCESS_TOKEN || process.env.MERCADOPAGO_ACCESS_TOKEN === 'CHAVE_NAO_CONFIGURADA') {
    return res.status(500).json({
      erro: 'Pagamento por PIX ainda não foi configurado. Adicione o MERCADOPAGO_ACCESS_TOKEN no arquivo .env do servidor.',
    });
  }

  try {
    const usuario = db.prepare('SELECT * FROM usuarios WHERE id = ?').get(req.usuario.id);

    const pagamento = await paymentClient.create({
      body: {
        transaction_amount: pedido.total_centavos / 100,
        description: `Pedido #${pedido.id} - Drogaria PeryPery`,
        payment_method_id: 'pix',
        payer: {
          email: usuario.email,
          first_name: usuario.nome.split(' ')[0],
        },
        external_reference: String(pedido.id),
        notification_url: `${process.env.BACKEND_URL || ''}/api/pagamentos/webhook`,
      },
    });

    db.prepare('UPDATE pedidos SET mercadopago_payment_id = ? WHERE id = ?').run(pagamento.id, pedido.id);

    res.json({
      payment_id: pagamento.id,
      status: pagamento.status,
      qr_code: pagamento.point_of_interaction?.transaction_data?.qr_code,
      qr_code_base64: pagamento.point_of_interaction?.transaction_data?.qr_code_base64,
    });
  } catch (erro) {
    console.error('Erro ao criar pagamento PIX:', erro);
    res.status(500).json({ erro: 'Não foi possível gerar a cobrança PIX. Verifique a chave do Mercado Pago.' });
  }
});

// POST /api/pagamentos/cartao -> processa pagamento com cartão (token gerado no front pelo SDK do Mercado Pago)
router.post('/cartao', exigirLogin, async (req, res) => {
  const { pedido_id, token, installments, payment_method_id, issuer_id } = req.body;
  const pedido = db.prepare('SELECT * FROM pedidos WHERE id = ?').get(pedido_id);

  if (!pedido) return res.status(404).json({ erro: 'Pedido não encontrado.' });
  if (pedido.usuario_id !== req.usuario.id) return res.status(403).json({ erro: 'Este pedido não é seu.' });
  if (!token) return res.status(400).json({ erro: 'Token do cartão não recebido (gerado pelo SDK do Mercado Pago no navegador).' });

  try {
    const usuario = db.prepare('SELECT * FROM usuarios WHERE id = ?').get(req.usuario.id);

    const pagamento = await paymentClient.create({
      body: {
        transaction_amount: pedido.total_centavos / 100,
        token,
        description: `Pedido #${pedido.id} - Drogaria PeryPery`,
        installments: installments || 1,
        payment_method_id,
        issuer_id,
        payer: { email: usuario.email },
        external_reference: String(pedido.id),
      },
    });

    db.prepare('UPDATE pedidos SET mercadopago_payment_id = ? WHERE id = ?').run(pagamento.id, pedido.id);

    if (pagamento.status === 'approved') {
      db.prepare('UPDATE pedidos SET status_pagamento = ? WHERE id = ?').run('pago', pedido.id);
    }

    res.json({ payment_id: pagamento.id, status: pagamento.status, status_detail: pagamento.status_detail });
  } catch (erro) {
    console.error('Erro ao processar cartão:', erro);
    res.status(500).json({ erro: 'Pagamento recusado ou dados do cartão inválidos.' });
  }
});

// POST /api/pagamentos/webhook -> o Mercado Pago chama esta rota sozinho quando o pagamento muda de status
// Configure esta URL pública no painel do Mercado Pago (Notificações > Webhooks)
router.post('/webhook', async (req, res) => {
  try {
    const { type, data } = req.body;
    if (type === 'payment' && data?.id) {
      const pagamento = await paymentClient.get({ id: data.id });
      const pedidoId = pagamento.external_reference;

      if (pedidoId) {
        const novoStatus = pagamento.status === 'approved' ? 'pago'
          : pagamento.status === 'rejected' ? 'recusado'
          : 'pendente';
        db.prepare('UPDATE pedidos SET status_pagamento = ? WHERE id = ?').run(novoStatus, pedidoId);
      }
    }
    res.sendStatus(200); // sempre responder 200, senão o Mercado Pago fica reenviando
  } catch (erro) {
    console.error('Erro no webhook do Mercado Pago:', erro);
    res.sendStatus(200);
  }
});

module.exports = router;
