const express = require('express');
const db = require('../db/database');
const { exigirAdmin } = require('../middleware/auth');

const router = express.Router();

function formatarProduto(p) {
  return {
    id: p.id,
    nome: p.nome,
    descricao: p.descricao,
    categoria_id: p.categoria_id,
    preco: p.preco_centavos / 100,
    estoque: p.estoque,
    exige_receita: !!p.exige_receita,
    imagem_url: p.imagem_url,
    ativo: !!p.ativo,
  };
}

// GET /api/produtos -> lista pública (só produtos ativos)
router.get('/', (req, res) => {
  const { categoria } = req.query;
  let produtos;
  if (categoria) {
    produtos = db.prepare(`
      SELECT produtos.* FROM produtos
      JOIN categorias ON categorias.id = produtos.categoria_id
      WHERE categorias.slug = ? AND produtos.ativo = 1
      ORDER BY produtos.nome
    `).all(categoria);
  } else {
    produtos = db.prepare('SELECT * FROM produtos WHERE ativo = 1 ORDER BY nome').all();
  }
  res.json(produtos.map(formatarProduto));
});

// GET /api/produtos/:id -> detalhe público
router.get('/:id', (req, res) => {
  const produto = db.prepare('SELECT * FROM produtos WHERE id = ? AND ativo = 1').get(req.params.id);
  if (!produto) return res.status(404).json({ erro: 'Produto não encontrado.' });
  res.json(formatarProduto(produto));
});

// ---- ROTAS DE ADMINISTRAÇÃO (exigem login de admin) ----

// GET /api/produtos/admin/todos -> lista tudo, inclusive inativos e estoque zerado
router.get('/admin/todos', exigirAdmin, (req, res) => {
  const produtos = db.prepare('SELECT * FROM produtos ORDER BY nome').all();
  res.json(produtos.map(formatarProduto));
});

// POST /api/produtos -> cria produto novo
router.post('/', exigirAdmin, (req, res) => {
  const { nome, descricao, categoria_id, preco, estoque, exige_receita, imagem_url } = req.body;
  if (!nome || preco == null || estoque == null) {
    return res.status(400).json({ erro: 'nome, preco e estoque são obrigatórios.' });
  }
  const resultado = db.prepare(`
    INSERT INTO produtos (nome, descricao, categoria_id, preco_centavos, estoque, exige_receita, imagem_url)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(nome, descricao || null, categoria_id || null, Math.round(preco * 100), estoque, exige_receita ? 1 : 0, imagem_url || null);

  const produto = db.prepare('SELECT * FROM produtos WHERE id = ?').get(resultado.lastInsertRowid);
  res.status(201).json(formatarProduto(produto));
});

// PUT /api/produtos/:id -> atualiza produto (nome, preço, estoque, categoria, etc.)
router.put('/:id', exigirAdmin, (req, res) => {
  const produto = db.prepare('SELECT * FROM produtos WHERE id = ?').get(req.params.id);
  if (!produto) return res.status(404).json({ erro: 'Produto não encontrado.' });

  const dados = {
    nome: req.body.nome ?? produto.nome,
    descricao: req.body.descricao ?? produto.descricao,
    categoria_id: req.body.categoria_id ?? produto.categoria_id,
    preco_centavos: req.body.preco != null ? Math.round(req.body.preco * 100) : produto.preco_centavos,
    estoque: req.body.estoque ?? produto.estoque,
    exige_receita: req.body.exige_receita != null ? (req.body.exige_receita ? 1 : 0) : produto.exige_receita,
    imagem_url: req.body.imagem_url ?? produto.imagem_url,
    ativo: req.body.ativo != null ? (req.body.ativo ? 1 : 0) : produto.ativo,
  };

  db.prepare(`
    UPDATE produtos SET nome=@nome, descricao=@descricao, categoria_id=@categoria_id,
      preco_centavos=@preco_centavos, estoque=@estoque, exige_receita=@exige_receita,
      imagem_url=@imagem_url, ativo=@ativo
    WHERE id = ${produto.id}
  `).run(dados);

  const atualizado = db.prepare('SELECT * FROM produtos WHERE id = ?').get(produto.id);
  res.json(formatarProduto(atualizado));
});

// PATCH /api/produtos/:id/estoque -> ajuste rápido de estoque (ex: repor mercadoria)
router.patch('/:id/estoque', exigirAdmin, (req, res) => {
  const { estoque } = req.body;
  if (estoque == null || estoque < 0) {
    return res.status(400).json({ erro: 'Informe um valor de estoque válido (0 ou mais).' });
  }
  const produto = db.prepare('SELECT * FROM produtos WHERE id = ?').get(req.params.id);
  if (!produto) return res.status(404).json({ erro: 'Produto não encontrado.' });

  db.prepare('UPDATE produtos SET estoque = ? WHERE id = ?').run(estoque, produto.id);
  res.json({ ok: true, estoque });
});

// DELETE /api/produtos/:id -> exclusão lógica (marca como inativo, não some do histórico de pedidos)
router.delete('/:id', exigirAdmin, (req, res) => {
  const produto = db.prepare('SELECT * FROM produtos WHERE id = ?').get(req.params.id);
  if (!produto) return res.status(404).json({ erro: 'Produto não encontrado.' });
  db.prepare('UPDATE produtos SET ativo = 0 WHERE id = ?').run(produto.id);
  res.json({ ok: true });
});

module.exports = router;
