const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const db = require('../db/database');
const { exigirLogin } = require('../middleware/auth');

const router = express.Router();

// Trava tentativas de login repetidas (proteção básica contra força bruta)
const limiteLogin = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 10,
  message: { erro: 'Muitas tentativas. Aguarde alguns minutos e tente novamente.' },
});

function validarEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function gerarToken(usuario) {
  return jwt.sign(
    { id: usuario.id, nome: usuario.nome, email: usuario.email, papel: usuario.papel },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
}

// POST /api/auth/cadastro
router.post('/cadastro', (req, res) => {
  const { nome, email, telefone, senha } = req.body;

  if (!nome || !email || !senha) {
    return res.status(400).json({ erro: 'Nome, e-mail e senha são obrigatórios.' });
  }
  if (!validarEmail(email)) {
    return res.status(400).json({ erro: 'Informe um e-mail válido.' });
  }
  if (senha.length < 6) {
    return res.status(400).json({ erro: 'A senha precisa ter pelo menos 6 caracteres.' });
  }

  const jaExiste = db.prepare('SELECT id FROM usuarios WHERE email = ?').get(email.toLowerCase());
  if (jaExiste) {
    return res.status(409).json({ erro: 'Já existe uma conta com esse e-mail.' });
  }

  const hash = bcrypt.hashSync(senha, 12); // 12 rounds: seguro e ainda rápido
  const resultado = db.prepare(`
    INSERT INTO usuarios (nome, email, telefone, senha_hash, papel)
    VALUES (?, ?, ?, ?, 'cliente')
  `).run(nome, email.toLowerCase(), telefone || null, hash);

  const usuario = { id: resultado.lastInsertRowid, nome, email: email.toLowerCase(), papel: 'cliente' };
  const token = gerarToken(usuario);

  res.status(201).json({ usuario, token });
});

// POST /api/auth/login
router.post('/login', limiteLogin, (req, res) => {
  const { email, senha } = req.body;
  if (!email || !senha) {
    return res.status(400).json({ erro: 'Informe e-mail e senha.' });
  }

  const usuario = db.prepare('SELECT * FROM usuarios WHERE email = ?').get(email.toLowerCase());
  if (!usuario) {
    return res.status(401).json({ erro: 'E-mail ou senha incorretos.' });
  }

  const senhaCorreta = bcrypt.compareSync(senha, usuario.senha_hash);
  if (!senhaCorreta) {
    return res.status(401).json({ erro: 'E-mail ou senha incorretos.' });
  }

  const token = gerarToken(usuario);
  res.json({
    usuario: { id: usuario.id, nome: usuario.nome, email: usuario.email, papel: usuario.papel },
    token,
  });
});

// GET /api/auth/me  -> dados de quem está logado (valida o token)
router.get('/me', exigirLogin, (req, res) => {
  res.json({ usuario: req.usuario });
});

module.exports = router;
