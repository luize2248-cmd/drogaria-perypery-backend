const express = require('express');
const db = require('../db/database');
const { exigirLogin, exigirAdmin } = require('../middleware/auth');

const router = express.Router();

function formatarPedido(pedido) {
  const itens = db.prepare(`
    SELECT itens_pedido.*, produtos.nome AS produto_nome
    FROM itens_pedido
    JOIN produtos ON produtos.id = itens_pedido.produto_id
    WHERE pedido_id = ?
  `).all(pedido.id);

  const endereco = pedido.endereco_id
    ? db.prepare('SELECT * FROM enderecos WHERE id = ?').get(pedido.endereco_id)
    : null;

  return {
    id: pedido.id,
    status_pedido: pedido.status_pedido,
    status_pagamento: pedido.status_pagamento,
    forma_pagamento: pedido.forma_pagamento,
    tipo_entrega: pedido.tipo_entrega,
    total: pedido.total_centavos / 100,
    criado_em: pedido.criado_em,
    endereco,
    itens: itens.map(i => ({
      produto_id: i.produto_id,
      nome: i.produto_nome,
      quantidade: i.quantidade,
      preco_unitario: i.preco_unitario_centavos / 100,
    })),
  };
}

// POST /api/pedidos -> cria um pedido de verdade (exige login) e baixa o estoque
router.post('/', exigirLogin, (req, res) => {
  const { itens, forma_pagamento, tipo_entrega, endereco } = req.body;

  if (!Array.isArray(itens) || itens.length === 0) {
    return res.status(400).json({ erro: 'O pedido precisa ter pelo menos um item.' });
  }
  if (!['pix', 'cartao', 'dinheiro'].includes(forma_pagamento)) {
    return res.status(400).json({ erro: 'Forma de pagamento inválida.' });
  }
  if (tipo_entrega === 'entrega' && !endereco) {
    return res.status(400).json({ erro: 'Informe o endereço de entrega.' });
  }

  // Tudo dentro de uma transação: ou baixa o estoque de tudo e cria o pedido, ou desfaz tudo se algo falhar
  const criarPedido = db.transaction(() => {
    let enderecoId = null;
    if (endereco) {
      const r = db.prepare(`
        INSERT INTO enderecos (usuario_id, cep, rua, numero, complemento, bairro, cidade, uf)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(req.usuario.id, endereco.cep || '', endereco.rua, endereco.numero, endereco.complemento || '', endereco.bairro, endereco.cidade, endereco.uf || '');
      enderecoId = r.lastInsertRowid;
    }

    let totalCentavos = 0;
    const itensValidados = [];

    for (const item of itens) {
      // Aceita tanto produto_id (catálogo vindo do backend) quanto nome
      // (compatível com o site estático atual, que ainda não busca produtos do backend)
      const produto = item.produto_id
        ? db.prepare('SELECT * FROM produtos WHERE id = ? AND ativo = 1').get(item.produto_id)
        : db.prepare('SELECT * FROM produtos WHERE nome = ? AND ativo = 1').get(item.nome);

      if (!produto) {
        throw new Error(`Produto "${item.nome || item.produto_id}" não encontrado no estoque real.`);
      }
      if (produto.estoque < item.quantidade) {
        throw new Error(`Estoque insuficiente para "${produto.nome}" (disponível: ${produto.estoque}).`);
      }
      totalCentavos += produto.preco_centavos * item.quantidade;
      itensValidados.push({ produto, quantidade: item.quantidade });
    }

    const resultadoPedido = db.prepare(`
      INSERT INTO pedidos (usuario_id, endereco_id, tipo_entrega, forma_pagamento, total_centavos)
      VALUES (?, ?, ?, ?, ?)
    `).run(req.usuario.id, enderecoId, tipo_entrega || 'entrega', forma_pagamento, totalCentavos);

    const pedidoId = resultadoPedido.lastInsertRowid;

    for (const { produto, quantidade } of itensValidados) {
      db.prepare(`
        INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario_centavos)
        VALUES (?, ?, ?, ?)
      `).run(pedidoId, produto.id, quantidade, produto.preco_centavos);

      // Baixa real do estoque
      db.prepare('UPDATE produtos SET estoque = estoque - ? WHERE id = ?').run(quantidade, produto.id);
    }

    return pedidoId;
  });

  try {
    const pedidoId = criarPedido();
    const pedido = db.prepare('SELECT * FROM pedidos WHERE id = ?').get(pedidoId);
    res.status(201).json(formatarPedido(pedido));
  } catch (erro) {
    res.status(400).json({ erro: erro.message });
  }
});

// GET /api/pedidos/meus -> histórico da pessoa logada
router.get('/meus', exigirLogin, (req, res) => {
  const pedidos = db.prepare('SELECT * FROM pedidos WHERE usuario_id = ? ORDER BY criado_em DESC').all(req.usuario.id);
  res.json(pedidos.map(formatarPedido));
});

// GET /api/pedidos/:id -> detalhe (só o dono do pedido ou admin pode ver)
router.get('/:id', exigirLogin, (req, res) => {
  const pedido = db.prepare('SELECT * FROM pedidos WHERE id = ?').get(req.params.id);
  if (!pedido) return res.status(404).json({ erro: 'Pedido não encontrado.' });
  if (pedido.usuario_id !== req.usuario.id && req.usuario.papel !== 'admin') {
    return res.status(403).json({ erro: 'Você não tem acesso a este pedido.' });
  }
  res.json(formatarPedido(pedido));
});

// ---- ADMINISTRAÇÃO ----

// GET /api/pedidos/admin/todos -> lista todos os pedidos (painel admin)
router.get('/admin/todos', exigirAdmin, (req, res) => {
  const pedidos = db.prepare('SELECT * FROM pedidos ORDER BY criado_em DESC').all();
  res.json(pedidos.map(formatarPedido));
});

// PATCH /api/pedidos/:id/status -> admin atualiza status (preparando, saiu para entrega, etc.)
router.patch('/:id/status', exigirAdmin, (req, res) => {
  const { status_pedido, status_pagamento } = req.body;
  const pedido = db.prepare('SELECT * FROM pedidos WHERE id = ?').get(req.params.id);
  if (!pedido) return res.status(404).json({ erro: 'Pedido não encontrado.' });

  db.prepare(`
    UPDATE pedidos SET
      status_pedido = COALESCE(?, status_pedido),
      status_pagamento = COALESCE(?, status_pagamento)
    WHERE id = ?
  `).run(status_pedido || null, status_pagamento || null, pedido.id);

  const atualizado = db.prepare('SELECT * FROM pedidos WHERE id = ?').get(pedido.id);
  res.json(formatarPedido(atualizado));
});

module.exports = router;
