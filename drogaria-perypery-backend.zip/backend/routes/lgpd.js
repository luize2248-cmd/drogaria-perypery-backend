// Implementação real dos direitos do titular previstos na LGPD (Lei 13.709/2018):
// acesso aos dados, portabilidade e eliminação (Art. 18).
// IMPORTANTE: isto cobre a parte técnica. A conformidade completa também exige
// uma Política de Privacidade revisada por advogado e a indicação formal de um
// Encarregado de Dados (DPO) — isso este código não substitui.
const express = require('express');
const db = require('../db/database');
const { exigirLogin } = require('../middleware/auth');

const router = express.Router();

// GET /api/lgpd/meus-dados -> exporta TODOS os dados que temos sobre a pessoa (Art. 18, II)
router.get('/meus-dados', exigirLogin, (req, res) => {
  const usuario = db.prepare('SELECT id, nome, email, telefone, papel, criado_em FROM usuarios WHERE id = ?').get(req.usuario.id);
  const enderecos = db.prepare('SELECT * FROM enderecos WHERE usuario_id = ?').all(req.usuario.id);
  const pedidos = db.prepare('SELECT * FROM pedidos WHERE usuario_id = ?').all(req.usuario.id);

  res.setHeader('Content-Disposition', 'attachment; filename="meus-dados-perypery.json"');
  res.json({
    exportado_em: new Date().toISOString(),
    usuario,
    enderecos,
    pedidos,
  });
});

// DELETE /api/lgpd/minha-conta -> elimina a conta e anonimiza os pedidos antigos (Art. 18, VI)
// Os pedidos não são apagados (existe obrigação fiscal/contábil de manter histórico de vendas),
// mas os dados pessoais neles são removidos/anonimizados.
router.delete('/minha-conta', exigirLogin, (req, res) => {
  const excluir = db.transaction(() => {
    // Anonimiza endereços ligados à conta
    db.prepare(`
      UPDATE enderecos SET rua = '[removido]', numero = '[removido]', complemento = '[removido]', bairro = '[removido]'
      WHERE usuario_id = ?
    `).run(req.usuario.id);

    // Anonimiza o cadastro em vez de apagar a linha (mantém o vínculo para o histórico fiscal dos pedidos)
    db.prepare(`
      UPDATE usuarios SET
        nome = '[conta excluída]',
        email = 'excluido-' || id || '@removido.local',
        telefone = NULL,
        senha_hash = 'conta_excluida'
      WHERE id = ?
    `).run(req.usuario.id);
  });

  excluir();
  res.json({ ok: true, mensagem: 'Sua conta e seus dados pessoais foram removidos.' });
});

module.exports = router;
