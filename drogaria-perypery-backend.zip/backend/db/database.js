// Conexão real com o banco de dados SQLite (arquivo em disco, persiste entre reinicializações).
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DB_PATH = path.join(__dirname, 'perypery.db');
const SCHEMA_PATH = path.join(__dirname, 'schema.sql');

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL'); // melhora concorrência de escrita/leitura

// Cria as tabelas se ainda não existirem (seguro rodar toda vez que o servidor inicia)
const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
db.exec(schema);

module.exports = db;
