-- ================================================================
-- Schema do banco de dados da Drogaria PeryPery (SQLite real)
-- ================================================================

CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  telefone TEXT,
  senha_hash TEXT NOT NULL,
  papel TEXT NOT NULL DEFAULT 'cliente' CHECK (papel IN ('cliente', 'admin')),
  criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS categorias (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS produtos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  descricao TEXT,
  categoria_id INTEGER REFERENCES categorias(id),
  preco_centavos INTEGER NOT NULL,          -- preço guardado em centavos (evita erro de ponto flutuante)
  estoque INTEGER NOT NULL DEFAULT 0,
  exige_receita INTEGER NOT NULL DEFAULT 0, -- 0 = não, 1 = sim
  imagem_url TEXT,
  ativo INTEGER NOT NULL DEFAULT 1,
  criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS enderecos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
  cep TEXT NOT NULL,
  rua TEXT NOT NULL,
  numero TEXT NOT NULL,
  complemento TEXT,
  bairro TEXT NOT NULL,
  cidade TEXT NOT NULL,
  uf TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pedidos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
  endereco_id INTEGER REFERENCES enderecos(id),
  tipo_entrega TEXT NOT NULL DEFAULT 'entrega' CHECK (tipo_entrega IN ('entrega', 'retirada')),
  forma_pagamento TEXT NOT NULL CHECK (forma_pagamento IN ('pix', 'cartao', 'dinheiro')),
  status_pagamento TEXT NOT NULL DEFAULT 'pendente' CHECK (status_pagamento IN ('pendente', 'pago', 'recusado', 'cancelado')),
  status_pedido TEXT NOT NULL DEFAULT 'recebido' CHECK (status_pedido IN ('recebido', 'preparando', 'saiu_para_entrega', 'pronto_retirada', 'concluido', 'cancelado')),
  total_centavos INTEGER NOT NULL,
  mercadopago_payment_id TEXT,
  criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS itens_pedido (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  pedido_id INTEGER NOT NULL REFERENCES pedidos(id),
  produto_id INTEGER NOT NULL REFERENCES produtos(id),
  quantidade INTEGER NOT NULL,
  preco_unitario_centavos INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_produtos_categoria ON produtos(categoria_id);
CREATE INDEX IF NOT EXISTS idx_pedidos_usuario ON pedidos(usuario_id);
CREATE INDEX IF NOT EXISTS idx_itens_pedido ON itens_pedido(pedido_id);
