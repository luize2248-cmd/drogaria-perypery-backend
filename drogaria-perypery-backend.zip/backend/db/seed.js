// Popula o banco com o administrador inicial e algumas categorias/produtos reais.
// Rode com: npm run seed
require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./database');

function upsertCategoria(nome, slug) {
  const existe = db.prepare('SELECT id FROM categorias WHERE slug = ?').get(slug);
  if (existe) return existe.id;
  const r = db.prepare('INSERT INTO categorias (nome, slug) VALUES (?, ?)').run(nome, slug);
  return r.lastInsertRowid;
}

function upsertProduto(p) {
  const existe = db.prepare('SELECT id FROM produtos WHERE nome = ?').get(p.nome);
  if (existe) {
    db.prepare('UPDATE produtos SET estoque = ? WHERE id = ?').run(p.estoque, existe.id);
    return existe.id;
  }
  const r = db.prepare(`
    INSERT INTO produtos (nome, descricao, categoria_id, preco_centavos, estoque, exige_receita, imagem_url)
    VALUES (@nome, @descricao, @categoria_id, @preco_centavos, @estoque, @exige_receita, @imagem_url)
  `).run(p);
  return r.lastInsertRowid;
}

// --- Administrador inicial ---
const adminEmail = process.env.ADMIN_EMAIL || 'admin@drogariaperypery.com';
const adminSenha = process.env.ADMIN_SENHA || 'troque_esta_senha_padrao';

const adminExiste = db.prepare('SELECT id FROM usuarios WHERE email = ?').get(adminEmail);
if (!adminExiste) {
  const hash = bcrypt.hashSync(adminSenha, 12);
  db.prepare(`
    INSERT INTO usuarios (nome, email, telefone, senha_hash, papel)
    VALUES (?, ?, ?, ?, 'admin')
  `).run('Administrador PeryPery', adminEmail, '86999101418', hash);
  console.log(`Admin criado -> e-mail: ${adminEmail} | senha: ${adminSenha}`);
  console.log('IMPORTANTE: troque essa senha assim que fizer login pela primeira vez.');
} else {
  console.log('Admin já existia, nada foi alterado.');
}

// --- Categorias ---
const catMuscular = upsertCategoria('Dores musculares', 'dores-musculares');
const catCabeca = upsertCategoria('Dor de cabeça', 'dor-cabeca');
const catPeito = upsertCategoria('Dor no peito / Azia', 'dor-peito');
const catFebre = upsertCategoria('Febre', 'febre');
const catBebe = upsertCategoria('Cuidados com o bebê', 'cuidados-bebe');
const catSuplementos = upsertCategoria('Suplementos & mais', 'outros');

// --- Produtos (preços em centavos) ---
const produtos = [
  { nome: 'FisioFort Pomada Massageadora 150g', descricao: 'Bio Instinto', categoria_id: catMuscular, preco_centavos: 3990, estoque: 20, exige_receita: 0, imagem_url: '' },
  { nome: 'Bálsamo Bengué Pomada 20g', descricao: 'EMS', categoria_id: catMuscular, preco_centavos: 1490, estoque: 30, exige_receita: 0, imagem_url: '' },
  { nome: 'Massageol Pomada 30g', descricao: 'Neo Química', categoria_id: catMuscular, preco_centavos: 1250, estoque: 25, exige_receita: 0, imagem_url: '' },
  { nome: 'Gelol Pomada 20g', descricao: 'Alívio da dor', categoria_id: catMuscular, preco_centavos: 1690, estoque: 25, exige_receita: 0, imagem_url: '' },
  { nome: 'Queimadol Pomada 30g', descricao: 'BellaPhytus', categoria_id: catMuscular, preco_centavos: 2490, estoque: 15, exige_receita: 0, imagem_url: '' },
  { nome: 'Dipirona Monoidratada 500mg 10comp', descricao: 'Medicamento genérico', categoria_id: catCabeca, preco_centavos: 690, estoque: 100, exige_receita: 0, imagem_url: '' },
  { nome: 'Ibuprofeno 100mg/mL Gotas 20mL', descricao: 'Geolab · Genérico', categoria_id: catCabeca, preco_centavos: 1390, estoque: 40, exige_receita: 0, imagem_url: '' },
  { nome: 'Omeprazol 20mg 28cáps', descricao: 'EMS · Genérico', categoria_id: catPeito, preco_centavos: 1590, estoque: 35, exige_receita: 1, imagem_url: '' },
  { nome: 'Pantoprazol Sódico 40mg 28comp', descricao: 'EMS · Genérico', categoria_id: catPeito, preco_centavos: 2190, estoque: 20, exige_receita: 1, imagem_url: '' },
  { nome: 'Cloridrato de Ranitidina 150mg 20comp', descricao: 'Medley · Genérico', categoria_id: catPeito, preco_centavos: 1890, estoque: 18, exige_receita: 1, imagem_url: '' },
  { nome: 'Amoxicilina 250mg/5mL Suspensão 150mL', descricao: 'Neo Química · Genérico', categoria_id: catFebre, preco_centavos: 2490, estoque: 22, exige_receita: 1, imagem_url: '' },
  { nome: 'Nistatina + Óxido de Zinco Pomada 30g', descricao: 'Neo Química · Assaduras', categoria_id: catBebe, preco_centavos: 1390, estoque: 20, exige_receita: 0, imagem_url: '' },
  { nome: 'Babymed Pomada para Assaduras 45g', descricao: 'Vitamina A+D', categoria_id: catBebe, preco_centavos: 1690, estoque: 20, exige_receita: 0, imagem_url: '' },
  { nome: 'Whey Protein 80% Growth 1kg', descricao: 'Growth Suplementos', categoria_id: catSuplementos, preco_centavos: 9990, estoque: 10, exige_receita: 0, imagem_url: '' },
  { nome: 'Creatina Hardcore IntegralMédica 300g', descricao: 'IntegralMédica', categoria_id: catSuplementos, preco_centavos: 6990, estoque: 10, exige_receita: 0, imagem_url: '' },
  { nome: 'Diazepam 5mg 30comp', descricao: 'Germed · Controlado', categoria_id: catSuplementos, preco_centavos: 2290, estoque: 8, exige_receita: 1, imagem_url: '' },
];

produtos.forEach(upsertProduto);
console.log(`${produtos.length} produtos verificados/inseridos.`);
console.log('Seed concluído.');
