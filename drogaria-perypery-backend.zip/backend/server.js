require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const orderRoutes = require('./routes/orders');
const paymentRoutes = require('./routes/payments');
const lgpdRoutes = require('./routes/lgpd');
const adminRoutes = require('./routes/admin');

const app = express();

// ---- Segurança básica ----
app.use(helmet()); // cabeçalhos de segurança (evita clickjacking, sniffing de MIME, etc.)
app.use(cors({
  origin: process.env.FRONTEND_URL || '*', // troque '*' pelo domínio real do site quando for pra produção
  credentials: true,
}));
app.use(express.json({ limit: '2mb' }));

// Limite geral de requisições (proteção simples contra abuso/DDoS básico)
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
}));

// ---- Rotas da API ----
app.use('/api/auth', authRoutes);
app.use('/api/produtos', productRoutes);
app.use('/api/pedidos', orderRoutes);
app.use('/api/pagamentos', paymentRoutes);
app.use('/api/lgpd', lgpdRoutes);
app.use('/api/admin', adminRoutes);

// ---- Painel administrativo (arquivos estáticos simples em /admin) ----
app.use('/admin', express.static(path.join(__dirname, 'admin')));

// ---- Verificação de saúde do servidor (útil para o serviço de hospedagem) ----
app.get('/api/status', (req, res) => {
  res.json({ ok: true, mensagem: 'API da Drogaria PeryPery no ar.' });
});

// ---- Tratamento de erros não previstos ----
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ erro: 'Erro interno do servidor.' });
});

const PORTA = process.env.PORT || 3000;
app.listen(PORTA, () => {
  console.log(`Servidor da Drogaria PeryPery rodando na porta ${PORTA}`);
  console.log(`Painel administrativo em: http://localhost:${PORTA}/admin`);
});
